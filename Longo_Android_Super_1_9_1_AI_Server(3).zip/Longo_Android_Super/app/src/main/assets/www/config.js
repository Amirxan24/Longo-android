// Android build injects the HTTPS endpoint through AndroidConfig.
// For the browser/PWA, set the full HTTPS endpoint here only if you host the app separately.
window.LONGO_API_URL = (window.AndroidConfig && typeof window.AndroidConfig.getApiUrl === 'function')
  ? window.AndroidConfig.getApiUrl()
  : '';
