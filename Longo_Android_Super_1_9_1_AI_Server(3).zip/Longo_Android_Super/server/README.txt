LONGO — AI BACKEND DEPLOYMENT (VERSION 1.9.1)

WHAT IS READY
- Node.js 20+ API: POST /api/chat and GET /api/health.
- OpenAI key is read only from server environment variables. Never put it in APK, config.js, or a public repository.
- Rate limit: 25 chat requests per IP per minute. Request body and message lengths are limited.
- CORS supports same-origin hosting, explicit ALLOWED_ORIGINS, and optional Android WebView Origin: null.
- Dockerfile is in the project root.

DEPLOY WITH DOCKER
1. Create a server/hosting project that accepts a Dockerfile and deploy this project folder as its build context.
2. Add environment secrets in the hosting dashboard: OPENAI_API_KEY (required), OPENAI_MODEL=gpt-4o-mini, ALLOW_NULL_ORIGIN=true.
3. Deploy with HTTPS enabled. Do not send the API key to the mobile app or to ChatGPT.
4. Open https://YOUR-DOMAIN/api/health. It must return {"ok":true,"aiConfigured":true}.
5. Keep the endpoint URL; it is needed to build the Android app.

BUILD ANDROID WITH THE SERVER URL
From the project root, in Android Studio terminal or a machine with Android SDK and Gradle wrapper installed:
  gradle :app:assembleDebug -PLONGO_API_URL=https://YOUR-DOMAIN/api/chat
For a release build, configure signing first and use assembleRelease. Do not distribute an unsigned debug APK.
The Android WebView reads the URL through a small JavaScript bridge. No API secret is embedded in the APK.

IMPORTANT
- The server cannot be deployed or connected until the owner creates hosting and supplies their own API key through the host's secret settings.
- OpenAI usage is billed separately according to the account's current API pricing and limits.
- Before public launch, add user authentication, per-user quotas, spending alerts, abuse monitoring, privacy policy and Google Play Billing. IP rate limiting alone is not a complete paid-user quota system.
- This server does not implement app subscriptions or user accounts.
