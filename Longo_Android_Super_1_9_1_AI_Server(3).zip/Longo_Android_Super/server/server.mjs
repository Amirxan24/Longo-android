import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const API_KEY = process.env.OPENAI_API_KEY || '';
const ALLOWED_ORIGINS = new Set((process.env.ALLOWED_ORIGINS || '').split(',').map(v => v.trim()).filter(Boolean));
const ALLOW_NULL_ORIGIN = process.env.ALLOW_NULL_ORIGIN === 'true';
const allowedFiles = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/config.js', ['config.js', 'text/javascript; charset=utf-8']],
  ['/manifest.webmanifest', ['manifest.webmanifest', 'application/manifest+json']],
  ['/sw.js', ['sw.js', 'text/javascript; charset=utf-8']],
  ['/icon.svg', ['icon.svg', 'image/svg+xml']]
]);
const requests = new Map();
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 25;
let requestChecks = 0;

function send(res, status, body, type = 'application/json; charset=utf-8', extraHeaders = {}) {
  res.writeHead(status, {
    'Content-Type': type,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; connect-src 'self' https://api.openai.com; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    ...extraHeaders
  });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}

function allowedByRateLimit(ip) {
  const now = Date.now();
  requestChecks += 1;
  // Prune expired IP entries periodically so the limiter cannot grow forever.
  if (requestChecks % 100 === 0 || requests.size > 5000) {
    for (const [key, value] of requests) {
      if (now - value.startedAt >= WINDOW_MS) requests.delete(key);
    }
  }
  const record = requests.get(ip);
  if (!record || now - record.startedAt >= WINDOW_MS) {
    requests.set(ip, { startedAt: now, count: 1 });
    return true;
  }
  record.count += 1;
  return record.count <= MAX_REQUESTS;
}

async function readJson(req) {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 16_000) throw Object.assign(new Error('Request too large'), { status: 413 });
  }
  try { return JSON.parse(raw || '{}'); }
  catch { throw Object.assign(new Error('Invalid JSON'), { status: 400 }); }
}

const server = createServer(async (req, res) => {
  let url;
  try { url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`); }
  catch { return send(res, 400, { error: 'Некорректный адрес запроса.' }); }

  if (req.method === 'GET' && url.pathname === '/api/health') {
    return send(res, 200, { ok: true, aiConfigured: Boolean(API_KEY) });
  }

  if (url.pathname === '/api/chat') {
    const origin = req.headers.origin;
    let corsHeaders = {};
    if (origin) {
      let allowed = false;
      if (origin === 'null') allowed = ALLOW_NULL_ORIGIN;
      else {
        try {
          const parsed = new URL(origin);
          allowed = parsed.host === req.headers.host || ALLOWED_ORIGINS.has(parsed.origin);
        } catch { allowed = false; }
      }
      if (!allowed) return send(res, 403, { error: 'Origin not allowed' });
      corsHeaders = {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Max-Age': '600',
        'Vary': 'Origin'
      };
    }
    if (req.method === 'OPTIONS') return send(res, 204, '', 'text/plain; charset=utf-8', corsHeaders);
    if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed' }, 'application/json; charset=utf-8', corsHeaders);
    const ip = req.socket.remoteAddress || 'unknown';
    if (!allowedByRateLimit(ip)) return send(res, 429, { error: 'Слишком много запросов. Подожди минуту.' }, 'application/json; charset=utf-8', corsHeaders);
    if (!API_KEY) return send(res, 503, { error: 'ИИ ещё не подключён: на сервере не задан OPENAI_API_KEY.' }, 'application/json; charset=utf-8', corsHeaders);

    try {
      const body = await readJson(req);
      const message = typeof body.message === 'string' ? body.message.trim() : '';
      if (!message || message.length > 1000) return send(res, 400, { error: 'Сообщение должно содержать от 1 до 1000 символов.' }, 'application/json; charset=utf-8', corsHeaders);
      const modes = {
        practice: 'Practice an everyday introductory English conversation.',
        work: 'Practice an English conversation about work, skills and job interviews.',
        travel: 'Practice an English conversation about travel and hotels.'
      };
      const mode = modes[body.mode] ? body.mode : 'practice';
      const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
      const messages = [
        { role: 'system', content: `You are Longo, a friendly English tutor. ${modes[mode]} Reply in clear, level-appropriate English. Correct important mistakes briefly in Russian, explain one useful phrase, and ask one natural follow-up question. Keep replies concise. Never claim to be a human.` },
        ...history.filter(item => item && ['user', 'assistant'].includes(item.role) && typeof item.content === 'string')
          .map(item => ({ role: item.role, content: item.content.slice(0, 1000) })),
        { role: 'user', content: message }
      ];
      const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: MODEL, messages, temperature: 0.7, max_tokens: 350 }),
        signal: AbortSignal.timeout(30_000)
      });
      const result = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        const status = upstream.status === 429 ? 503 : 502;
        return send(res, status, { error: 'Сервис ИИ временно недоступен. Попробуй позже.' }, 'application/json; charset=utf-8', corsHeaders);
      }
      const reply = result.choices?.[0]?.message?.content?.trim();
      if (!reply) return send(res, 502, { error: 'ИИ вернул пустой ответ.' }, 'application/json; charset=utf-8', corsHeaders);
      return send(res, 200, { reply }, 'application/json; charset=utf-8', corsHeaders);
    } catch (error) {
      const status = error.status || (error.name === 'TimeoutError' ? 504 : 500);
      return send(res, status, { error: status === 504 ? 'Истекло время ожидания ответа ИИ.' : 'Не удалось обработать запрос.' }, 'application/json; charset=utf-8', corsHeaders);
    }
  }

  if (req.method === 'GET' && allowedFiles.has(url.pathname)) {
    const [filename, type] = allowedFiles.get(url.pathname);
    try { return send(res, 200, await readFile(path.join(ROOT, filename), 'utf8'), type); }
    catch { return send(res, 404, { error: 'File not found' }); }
  }
  return send(res, 404, { error: 'Not found' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Longo server listening on port ${PORT}; AI ${API_KEY ? 'configured' : 'not configured'}.`);
});
