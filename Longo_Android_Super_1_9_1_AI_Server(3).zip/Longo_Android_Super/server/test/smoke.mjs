import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { once } from 'node:events';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SERVER = path.resolve(HERE, '..', 'server.mjs');

async function freePort() {
  const probe = createServer();
  probe.listen(0, '127.0.0.1');
  await once(probe, 'listening');
  const port = probe.address().port;
  await new Promise(resolve => probe.close(resolve));
  return port;
}

const port = await freePort();
const child = spawn(process.execPath, [SERVER], {
  cwd: path.dirname(SERVER),
  env: { ...process.env, PORT: String(port), OPENAI_API_KEY: '', ALLOW_NULL_ORIGIN: 'true' },
  stdio: ['ignore', 'pipe', 'pipe']
});
let logs = '';
child.stdout.on('data', chunk => logs += chunk);
child.stderr.on('data', chunk => logs += chunk);
const base = `http://127.0.0.1:${port}`;

try {
  let ready = false;
  for (let i = 0; i < 40; i++) {
    if (child.exitCode !== null) throw new Error(`Server exited early: ${logs}`);
    try {
      const response = await fetch(`${base}/api/health`);
      if (response.ok) { ready = true; break; }
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert.equal(ready, true, `Server did not start: ${logs}`);

  const health = await fetch(`${base}/api/health`).then(r => r.json());
  assert.deepEqual(health, { ok: true, aiConfigured: false });

  const home = await fetch(base);
  assert.equal(home.status, 200);
  assert.match(home.headers.get('content-type'), /text\/html/);
  assert.match(await home.text(), /Longo/);

  const config = await fetch(`${base}/config.js`);
  assert.equal(config.status, 200);
  assert.match(await config.text(), /LONGO_API_URL/);

  const privateFile = await fetch(`${base}/server.mjs`);
  assert.equal(privateFile.status, 404);

  const wrongMethod = await fetch(`${base}/api/chat`);
  assert.equal(wrongMethod.status, 405);

  const wrongOrigin = await fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', origin: 'https://attacker.invalid' },
    body: JSON.stringify({ message: 'Hello' })
  });
  assert.equal(wrongOrigin.status, 403);

  const preflight = await fetch(`${base}/api/chat`, {
    method: 'OPTIONS',
    headers: { origin: 'null', 'access-control-request-method': 'POST', 'access-control-request-headers': 'content-type' }
  });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers.get('access-control-allow-origin'), 'null');

  const noKey = await fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', origin: 'null' },
    body: JSON.stringify({ message: 'Hello' })
  });
  assert.equal(noKey.status, 503);
  assert.match((await noKey.json()).error, /OPENAI_API_KEY/);
  assert.equal(noKey.headers.get('access-control-allow-origin'), 'null');

  console.log('Longo server smoke tests: 9 checks passed.');
} finally {
  child.kill('SIGTERM');
  await Promise.race([once(child, 'exit'), new Promise(resolve => setTimeout(resolve, 1500))]);
  if (child.exitCode === null) child.kill('SIGKILL');
}
